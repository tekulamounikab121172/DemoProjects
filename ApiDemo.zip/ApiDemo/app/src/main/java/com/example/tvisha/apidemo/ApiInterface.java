package com.example.tvisha.apidemo;


import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;


public interface ApiInterface {

    @FormUrlEncoded
    @POST("login")
    Call<ApiResponse> getOtp(@Field("username") String username, @Field("token") String token);

    @GET("otpVerify")
    Call<MovieResponse> getLoginResult(@Query("otp") String otp);

   /* @GET("movie/{id}")
    Call<MoviesResponse> getMovieDetails(@Path("id") int id, @Query("api_key") String apiKey);*/
}