package com.example.tvisha.apidemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/*
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
*/
public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    // TODO - insert your themoviedb.org API KEY here

    EditText username,otp;
    Button next,login;
    String un,op;
    ApiInterface apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        username=findViewById(R.id.username);
        otp=findViewById(R.id.otp);
        next=findViewById(R.id.next);
        login=findViewById(R.id.login);

        final String token="Y29mZmVlbWFoYWxjYWZl";

        apiService = ApiClient.getClient().create(ApiInterface.class);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "clicked", Toast.LENGTH_LONG).show();

                String un = username.getText().toString();

                if (un.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_LONG).show();
                    return;
                }

                Call<ApiResponse> call = apiService.getOtp(un, token);
                call.enqueue(new Callback<ApiResponse>() {
                    @Override
                    public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                        ApiResponse apiResponse = response.body();

                        if (apiResponse != null){
                            if (apiResponse.isSuccess()){
                                Log.e("response","success");
                                Toast.makeText(getApplicationContext(),""+apiResponse.getOtp(),Toast.LENGTH_LONG).show();
                                Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_LONG).show();
                            }else {
                                Log.e("response",apiResponse.getMessage());
                                Toast.makeText(getApplicationContext(),apiResponse.getMessage(),Toast.LENGTH_LONG).show();
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"response is empty",Toast.LENGTH_LONG).show();
                            Log.e("response","Response is empty");
                        }

                    }

                    @Override
                    public void onFailure(Call<ApiResponse> call, Throwable t) {
                        Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG).show();
                        Log.e("response","failed");
                    }


                });
            }
        });


    }
}