package com.example.tvisha.apidemo;

import java.util.List;

        import com.google.gson.annotations.SerializedName;

        import java.util.ArrayList;
        import java.util.List;


public class Movie {
    @SerializedName("user_name")
    private String userName;


    public Movie(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }


}