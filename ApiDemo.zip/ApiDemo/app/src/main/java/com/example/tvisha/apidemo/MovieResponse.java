package com.example.tvisha.apidemo;

/**
 * Created by tvisha on 8/6/18.
 */


import com.google.gson.annotations.SerializedName;

import java.util.List;


public class MovieResponse {
    @SerializedName("otp")
    private String otp;
    @SerializedName("result")
    private boolean result;




    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }


    public boolean getResult() {
        return result;
    }

    public void setOtp(boolean result) {
        this.result = result;
    }


}
