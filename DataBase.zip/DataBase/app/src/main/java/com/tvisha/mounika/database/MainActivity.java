package com.tvisha.mounika.database;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    String name="",age="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        try{
            SQLiteDatabase myDatabase=this.openOrCreateDatabase("Users",MODE_PRIVATE,null);
            myDatabase.execSQL("CREATE TABLE IF NOT EXISTS users (name VARCHAR,age INT(3))");
           // myDatabase.execSQL("CREATE TABLE IF NOT EXISTS newUsers (name VARCHAR,age INT(3),id INTEGER PRIMARY KEY)");
           // myDatabase.execSQL("INSERT INTO newUsers (name,age) VALUES ('Tommy',12)"); no need id field
            myDatabase.execSQL("INSERT INTO users (name,age) VALUES ('Tommy',12)");
            myDatabase.execSQL("INSERT INTO users (name,age) VALUES ('Rob',21)");
            //myDatabase.execSQL("DELETE FROM users WHERE name='Tommy' LIMIT 1");
            //myDatabase.execSQL("UPDATE users SET age=2 WHERE name='Tommy'");
            Cursor c=myDatabase.rawQuery("SELECT * FROM users",null);
            //Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE name LIKE '%T%' LIMIT 1",null);
            //Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE name LIKE '%T%'",null);
           // Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE name LIKE 'T%'",null);
            //Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE name='Tommy' AND age=22",null);

            //Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE name='Tommy'",null);
            //Cursor c=myDatabase.rawQuery("SELECT * FROM users WHERE age<18",null);
            int nameIndex=c.getColumnIndex("name");
            int ageIndex=c.getColumnIndex("age");
            c.moveToFirst();


            while (c!=null)
            {

                Log.i("name",c.getString(nameIndex));
                name=c.getString(nameIndex);
                Log.i("age",Integer.toString(c.getInt(ageIndex)));
                age=Integer.toString(c.getInt(ageIndex));
                Toast.makeText(MainActivity.this,"name: "+name,Toast.LENGTH_LONG).show();
                Toast.makeText(MainActivity.this,"age: "+age,Toast.LENGTH_LONG).show();
                c.moveToNext();
            }

        }catch (Exception e)
        {
            Toast.makeText(MainActivity.this,"Exception occurred",Toast.LENGTH_LONG).show();
            e.printStackTrace();

        }

    }
}
