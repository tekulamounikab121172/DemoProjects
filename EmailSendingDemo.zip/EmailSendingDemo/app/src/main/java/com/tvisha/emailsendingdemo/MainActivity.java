package com.tvisha.emailsendingdemo;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText recipient,subject,messageBody,to;
Button send;
String rec,sub,msg,t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recipient=findViewById(R.id.recipient);
        to=findViewById(R.id.to);
        subject=findViewById(R.id.subject);
        messageBody=findViewById(R.id.message);
        send=findViewById(R.id.send);

        recipient.setFocusableInTouchMode(true);
        recipient.setFocusable(true);
        recipient.requestFocus();
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .showSoftInput(recipient, InputMethodManager.SHOW_FORCED);
        recipient.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ( event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    to.setFocusableInTouchMode(true);
                    to.setFocusable(true);
                    to.requestFocus();
                    ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                            .showSoftInput(to, InputMethodManager.SHOW_FORCED);
                    return true;
                }
                return true;
            }
        });
        to.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ( event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    subject.setFocusableInTouchMode(true);
                    subject.setFocusable(true);
                    subject.requestFocus();
                    ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                            .showSoftInput(subject, InputMethodManager.SHOW_FORCED);
                    return true;
                }
                return true;
            }
        });
        subject.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ( event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    messageBody.setFocusableInTouchMode(true);
                    messageBody.setFocusable(true);
                    messageBody.requestFocus();
                    ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                            .showSoftInput(messageBody, InputMethodManager.SHOW_FORCED);
                    return true;
                }
                return true;
            }
        });
        messageBody.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ( event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    send.setEnabled(false);
                    validate();
                    return true;
                }
                return true;
            }
        });
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send.setEnabled(false);
                validate();
            }
        });

    }
    private void validate(){
        msg=messageBody.getText().toString();
        rec=recipient.getText().toString();
        sub=subject.getText().toString();
        t=to.getText().toString();
        if(rec.isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Please enter from email", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else  if(t.isEmpty())
        {
            Toast.makeText(getApplicationContext(), "Please enter to email", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else  if(sub.isEmpty() || sub.length()==0)
        {
            Toast.makeText(getApplicationContext(), "Please enter subject", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else  if(msg.isEmpty() || msg.length()==0)
        {
            Toast.makeText(getApplicationContext(), "Please enter message", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else
        {
            sendEmail();

        }

    }

    protected void sendEmail() {
        closeKeyboard();
        send.setEnabled(true);
        Log.i("Send email", "");
       // String[] TO = {""};
        String[] TO = {t};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);

        emailIntent.setData(Uri.parse(rec));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, sub);
        emailIntent.putExtra(Intent.EXTRA_TEXT, msg);

        try {
            startActivity(Intent.createChooser(emailIntent, "Send mail..."));
            finish();
            Log.e("Finished sending email", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(MainActivity.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }
    }
    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
