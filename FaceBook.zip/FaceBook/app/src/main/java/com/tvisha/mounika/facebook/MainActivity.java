package com.tvisha.mounika.facebook;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import org.json.JSONException;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;


public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.this.getClass().getName();

    private CallbackManager callbackManager;
    private AccessToken accessToken;

    private LoginButton loginButton;
    private RelativeLayout rlProfileArea;
    private TextView tvName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initParameters();
        initViews();
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        // Add code to print out the key hash
        //7xNcWpjkeVlgSTaLArGBFs1nfwo=
        try {
           PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHAz");
                md.update(signature.toByteArray());
               Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
               // Toast.makeText(getApplicationContext(), "User logged out successfully", Toast.LENGTH_LONG).show();
           }
       } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

       }

        AccessTokenTracker accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(
                    AccessToken oldAccessToken,
                    AccessToken currentAccessToken) {

                if (currentAccessToken == null) {
                   // Log.d(TAG, “User logged out successfully”);
                    Toast.makeText(getApplicationContext(), "User logged out successfully", Toast.LENGTH_LONG).show();
                    rlProfileArea.setVisibility(View.GONE);
                }
            }
        };

    }

    public void initParameters() {
        accessToken = AccessToken.getCurrentAccessToken();
        callbackManager = CallbackManager.Factory.create();

    }

    public void initViews() {

        loginButton = (LoginButton) findViewById(R.id.activity_main_btn_login);
        rlProfileArea = (RelativeLayout) findViewById(R.id.activity_main_rl_profile_area);
        tvName = (TextView) findViewById(R.id.activity_main_tv_name);

        loginButton.setReadPermissions(Arrays.asList(new String[]{"email", "user_birthday", "user_hometown"}));

        if (accessToken != null) {
            //getProfileData();
        } else {
            rlProfileArea.setVisibility(View.GONE);
        }

// Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
               // Log.d(TAG, “User login successfully”);
                Toast.makeText(getApplicationContext(), "User loin successfully", Toast.LENGTH_LONG).show();
                //getProfileData();
            }

            @Override
            public void onCancel() {
                // App code
                //Log.d(TAG, “User cancel login”);
                Toast.makeText(getApplicationContext(), "User cancel", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onError(FacebookException exception) {
                // App code
                //Log.d(TAG, “Problem for login”);
                Toast.makeText(getApplicationContext(), "problem for login", Toast.LENGTH_LONG).show();
            }

        });





    }
    @Override
    protected void onActivityResult ( int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }
    public void getProfileData(){
        try {
            accessToken = AccessToken.getCurrentAccessToken();
            rlProfileArea.setVisibility(View.VISIBLE);
            GraphRequest request = GraphRequest.newMeRequest(
                    accessToken,
                    new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted(
                                JSONObject object,
                                GraphResponse response) {
                            Log.d(TAG, "Graph Object :"+object);
                            try {
                                String name = object.getString("name");
                                tvName.setText("Welcome, " + name);

                                Log.d(TAG, "Name :"+name);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id, name, link, birthday, gender, email");
            request.setParameters(parameters);
            request.executeAsync();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}




/*
public class MainActivity extends AppCompatActivity {
    private AccessToken accessToken;
    private CallbackManager callbackManager;
    private LoginButton loginButton;
    private RelativeLayout rlProfileArea;
    private TextView tvName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //FacebookSdk.sdkInitialize(getApplicationContext());
        //AppEventsLogger.activateApp(this);
        initParameters();
        initViews();
        String key;
        //7xNcWpjkeVlgSTaLArGBFs1nfwo=
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                key = Base64.encodeToString(md.digest(), Base64.DEFAULT);
                Log.i("key value", key);
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
                Toast.makeText(getApplicationContext(), Base64.encodeToString(md.digest(), Base64.DEFAULT), Toast.LENGTH_LONG).show();
            }
        } catch (PackageManager.NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }
        AccessTokenTracker accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(
                    AccessToken oldAccessToken,
                    AccessToken currentAccessToken) {

                if (currentAccessToken == null) {
                    //Log.d(TAG, “User logged out successfully”);
                    Toast.makeText(getApplicationContext(), "User logged out successfully", Toast.LENGTH_LONG).show();
                    rlProfileArea.setVisibility(View.GONE);
                }
            }
        };
    }




    public void initParameters() {
        accessToken = AccessToken.getCurrentAccessToken();
        callbackManager = CallbackManager.Factory.create();

    }

    public void initViews() {

        loginButton = (LoginButton) findViewById(R.id.activity_main_btn_login);
        rlProfileArea = (RelativeLayout) findViewById(R.id.activity_main_rl_profile_area);
        tvName = (TextView) findViewById(R.id.activity_main_tv_name);

        loginButton.setReadPermissions(Arrays.asList(new String[]{"email", "user_birthday", "user_hometown"}));

        if (accessToken != null) {
            getProfileData();
        } else {
            rlProfileArea.setVisibility(View.GONE);
        }
        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                //Log.d(TAG, “User login successfully”);
                getProfileData();
            }

            @Override
            public void onCancel() {
                // App code
                //Log.d(TAG, “User cancel login”);
            }
            @Override
            public void onError(FacebookException exception) {
                // App code
                Log.d(TAG, “Problem for login”);
            }
        });

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }



    }





    public void getProfileData() {
        try {
            accessToken = AccessToken.getCurrentAccessToken();
            rlProfileArea.setVisibility(View.VISIBLE);
            GraphRequest request = GraphRequest.newMeRequest(
                    accessToken,
                    new GraphRequest.GraphJSONObjectCallback() {
                        @Override
                        public void onCompleted(
                                JSONObject object,
                                GraphResponse response) {
                            //Log.d(TAG, “Graph Object :” + object);
                            try {
                                String name = object.getString("name");
                                tvName.setText("Welcome," + name);

                                //Log.d(TAG, “Name :” + name);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,link,birthday,gender,email");
            request.setParameters(parameters);
            request.executeAsync();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


*/
