package com.example.tvisha.fontsdemo;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.util.Locale;


public class MainActivity extends AppCompatActivity {
    TextView msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        msg=findViewById(R.id.msg);
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "fonts/Playfair_Display_Regular.otf");
        msg.setTypeface(custom_font);


    }
}
