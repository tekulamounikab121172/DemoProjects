package com.tvisha.loadingview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ldoublem.loadingviewlib.LVCircular;
import com.ldoublem.loadingviewlib.LVCircularCD;
import com.ldoublem.loadingviewlib.view.LVCircularRing;
import com.ldoublem.loadingviewlib.view.LVCircularSmile;
import com.ldoublem.loadingviewlib.view.LVEatBeans;
import com.ldoublem.loadingviewlib.view.LVRingProgress;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int color=getColor(R.color.colorAccent);
        int color1=getColor(R.color.colorPrimaryDark);

        LVCircularCD  lvCircularCD=findViewById(R.id.lvCircularCD);
        lvCircularCD. setViewColor(color);
        lvCircularCD.startAnim();

        LVCircularRing   lvCircularRing=findViewById(R.id.lvCircularRing);
        lvCircularRing. setBarColor(color);
       // lvCircularRing.setViewColor(color1);
        lvCircularRing.startAnim();

        LVCircular   lvCircular=findViewById(R.id.lvCircular);
        lvCircular.setRoundColor(color);
        lvCircular.setViewColor(color);
        lvCircular.startAnim();

        LVCircularSmile lvCircularSmile=findViewById(R.id.lvCircularSmile);
        lvCircularSmile.setViewColor(color);
       // lvCircular.setViewColor(color1);
        lvCircularSmile.startAnim();

        LVRingProgress lvRingProgress=findViewById(R.id.lvRingProgress);
        lvRingProgress.setViewColor(color);
       // lvCircular.setViewColor(color1);
        lvRingProgress.startAnim();


        LVEatBeans lvEatBeans=findViewById(R.id.lvEatBeans);
        lvEatBeans.setViewColor(color);
       // lvCircular.setViewColor(color1);
        lvEatBeans.startAnim();

    }
}
