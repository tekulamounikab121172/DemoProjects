package com.example.tvisha.otp;


import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;


public interface ApiInterface {

    @FormUrlEncoded
    @POST("login")
    Call<ApiResponse> getOtp(@Field("username") String username, @Field("token") String token);

    @FormUrlEncoded
    @POST("otpVerify")
    Call<OtpVerificationResponse> verifyOtp(@Field("user_id") String username, @Field("otp") String otp, @Field("token") String token);



}