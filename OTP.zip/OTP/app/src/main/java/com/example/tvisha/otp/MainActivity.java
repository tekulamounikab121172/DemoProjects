package com.example.tvisha.otp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity  extends AppCompatActivity {
    ApiInterface apiService;
    String un;
    EditText mobilenumber;
    static  String uid;
    Button next;
    final String token="Y29mZmVlbWFoYWxjYWZl";
    SharedPreferences sharedPreferences;
    int count=0;
    int enter=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        next= findViewById(R.id.next) ;

        mobilenumber=findViewById(R.id.mobileNumber);
        apiService = ApiClient.getClient().create(ApiInterface.class);

        mobilenumber.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {


                if(event.getKeyCode() == KeyEvent.KEYCODE_ENTER)
                {



                    un = mobilenumber.getText().toString();
                    if (un.isEmpty()) {
                        Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_LONG).show();
                        return true;
                    }
                    else if(un.length()==10) {

                        if(count==0) {
                            closeKeyboard();
                            count=1;
                            getOtp();
                        }
                        return true;

                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_LONG).show();
                        return true;
                    }


                }
                return false;
            }
        });


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                un = mobilenumber.getText().toString();


                if (un.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_LONG).show();
                    return;
                }
                if(count==0)
                {
                    count=1;
                    next.setEnabled(false);
                    closeKeyboard();
                    getOtp();
                }

            }
        });
    }
    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
    private void  getOtp(){


        un = mobilenumber.getText().toString();

        next.setVisibility(View.INVISIBLE);
        Call<ApiResponse> call = apiService.getOtp(un, token);
        call.enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {
                ApiResponse apiResponse = response.body();

                if (apiResponse != null){
                    if (apiResponse.isSuccess()){

                        String userId=apiResponse.getUser_id();
                        int otp=apiResponse.getOtp();
                        uid=apiResponse.getUser_id();

                        sharedPreferences=getSharedPreferences("com.example.tvisha.otp", Context.MODE_PRIVATE);
                        sharedPreferences.edit().putString("userId", userId).apply();
                        sharedPreferences.edit().putBoolean("login",true).apply();
                        sharedPreferences.edit().putInt("otp",apiResponse.getOtp()).apply();
                        Intent intent = new Intent(MainActivity.this, OtpActivity.class);
                        intent.putExtra("userId",userId);
                        intent.putExtra("mobileNumber",un);
                        startActivity(intent);
                        finish();

                    }else {
                        count=0;

                        Toast.makeText(getApplicationContext(),apiResponse.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                else {

                    Toast.makeText(getApplicationContext(),"response is empty",Toast.LENGTH_LONG).show();

                }

            }

            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {

                next.setSaveEnabled(true);

                next.setVisibility(View.VISIBLE);
                Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();

            }


        });
    }
}
