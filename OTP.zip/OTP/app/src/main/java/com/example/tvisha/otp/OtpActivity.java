package com.example.tvisha.otp;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import android.widget.ProgressBar;

import android.widget.TextView;
import android.widget.Toast;


import com.stfalcon.smsverifycatcher.OnSmsCatchListener;
import com.stfalcon.smsverifycatcher.SmsVerifyCatcher;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class
OtpActivity extends AppCompatActivity {
    EditText otp;
    String OTP;

    ApiInterface apiService;
    Intent intent;

    ProgressBar progressBar;
    String userId = "";
    final String token = "Y29mZmVlbWFoYWxjYWZl";
    int count = 0, msg = 0;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_otp);

        otp = findViewById(R.id.otp);


        intent = getIntent();
        apiService = ApiClient.getClient().create(ApiInterface.class);
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.tvisha.otp", Context.MODE_PRIVATE);
        userId = sharedPreferences.getString("userId", "");
        if (checkAndRequestPermissions()) {

        }

        //validateOtp();


    }
    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                final String message = intent.getStringExtra("message");

                TextView tv = (TextView) findViewById(R.id.txtview);
                String abcd=message.replaceAll("[^0-9]","");
                tv.setText(abcd);
            }
        }
    };

    @Override
    public void onResume() {
        LocalBroadcastManager.getInstance(this).
                registerReceiver(receiver, new IntentFilter("otp"));
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
    }


    private void closeKeyboard() {
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


    private void validateOtp() {
        closeKeyboard();

        OTP = otp.getText().toString();
        if (OTP.length() > 0) {


            Call<OtpVerificationResponse> call = apiService.verifyOtp(userId, OTP, token);
            call.enqueue(new Callback<OtpVerificationResponse>() {
                @Override
                public void onResponse(Call<OtpVerificationResponse> call, Response<OtpVerificationResponse> response) {
                    OtpVerificationResponse apiResponse = response.body();

                    if (apiResponse != null) {
                        if (apiResponse.isSuccess()) {

                            Toast.makeText(getApplicationContext(), apiResponse.getMessage(), Toast.LENGTH_LONG).show();

                        } else {
                            progressBar.setVisibility(View.INVISIBLE);
                            Toast.makeText(getApplicationContext(), apiResponse.getMessage(), Toast.LENGTH_LONG).show();
                            return;
                        }
                    } else {
                        progressBar.setVisibility(View.INVISIBLE);
                        Log.e("message", "response is empty");
                        // Toast.makeText(getApplicationContext(),"response is empty",Toast.LENGTH_LONG).show();

                    }

                }

                @Override
                public void onFailure(Call<OtpVerificationResponse> call, Throwable t) {

                    Toast.makeText(getApplicationContext(), "Failed", Toast.LENGTH_LONG).show();
                }
            });


        } else {
            Toast.makeText(getApplicationContext(), "Please Enter OTP", Toast.LENGTH_LONG).show();
            return;
        }
    }

    private  boolean checkAndRequestPermissions() {
        int permissionSendMessage = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS);

        int receiveSMS = ContextCompat.checkSelfPermission(this,
                Manifest.permission.RECEIVE_SMS);

        int readSMS = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_SMS);
        List<String> listPermissionsNeeded = new ArrayList<>();

        if (receiveSMS != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.RECEIVE_MMS);
        }
        if (readSMS != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.READ_SMS);
        }
        if (permissionSendMessage != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.SEND_SMS);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                    REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

}