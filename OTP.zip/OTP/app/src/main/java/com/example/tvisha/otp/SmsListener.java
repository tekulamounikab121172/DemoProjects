package com.example.tvisha.otp;

/**
 * Created by tvisha on 19/6/18.
 */

public interface SmsListener {
     void messageReceived(String messageText);

}
