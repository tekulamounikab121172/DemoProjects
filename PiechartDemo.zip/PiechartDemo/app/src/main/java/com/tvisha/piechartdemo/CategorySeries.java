package com.tvisha.piechartdemo;

/**
 * Created by tvisha on 29/6/18.
 */

class CategorySeries {
    private int itemCount;

    public void add(String s, double value) {
    }

    public int getItemCount() {
        return itemCount;
    }
}
