package com.tvisha.piechartdemo;

/**
 * Created by tvisha on 29/6/18.
 */

class DefaultRenderer {

    boolen applyBackgroundColor;
    private int selectableBuffer;

    public void setApplyBackgroundColor(boolean applyBackgroundColor) {
        this.applyBackgroundColor = applyBackgroundColor;
    }

    public void setBackgroundColor(int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public void setChartTitleTextSize(int chartTitleTextSize) {
        this.chartTitleTextSize = chartTitleTextSize;
    }

    public void setLabelsTextSize(int labelsTextSize) {
        this.labelsTextSize = labelsTextSize;
    }

    public void setLegendTextSize(int legendTextSize) {
        this.legendTextSize = legendTextSize;
    }

    public void setMargins(int[] margins) {
        this.margins = margins;
    }

    public void setZoomButtonsVisible(boolean zoomButtonsVisible) {
        this.zoomButtonsVisible = zoomButtonsVisible;
    }

    public void setStartAngle(int startAngle) {
        this.startAngle = startAngle;
    }

    public void addSeriesRenderer(SimpleSeriesRenderer renderer) {
    }

    public void setClickEnabled(boolean clickEnabled) {
        this.clickEnabled = clickEnabled;
    }

    public void setSelectableBuffer(int selectableBuffer) {
        this.selectableBuffer = selectableBuffer;
    }
}
