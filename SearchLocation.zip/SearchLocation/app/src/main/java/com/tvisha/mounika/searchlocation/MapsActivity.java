package com.tvisha.mounika.searchlocation;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    //Button btn=(Button) findViewById(R.id.search);

    LocationManager locationManager;
    LocationListener locationListener;



        public void searchLocation(View v) {
            EditText data=(EditText) findViewById(R.id.data);
            String g = data.getText().toString();

            Geocoder geocoder = new Geocoder(getBaseContext());
            List<Address> addresses = null;

            try {
                // Getting a maximum of 3 Address that matches the input
                // text
                addresses = geocoder.getFromLocationName(g, 3);
                if (addresses != null && !addresses.equals(""))
                    search(addresses);

            } catch (Exception e) {

            }

        }

    protected void search(List<Address> addresses) {
        if(addresses.size()>0)
        {
            Address address = (Address) addresses.get(0);
            double home_long = address.getLongitude();
            double home_lat= address.getLatitude();
            Toast.makeText(MapsActivity.this,"Longitude:"+home_long,Toast.LENGTH_SHORT).show();
            Toast.makeText(MapsActivity.this,"Latitude:"+home_lat,Toast.LENGTH_SHORT).show();
            Log.i("longitude", String.valueOf(home_long));
            Log.i("latitude",String.valueOf(home_lat));
            LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());

            String addressText = String.format(
                    "%s, %s",
                    address.getMaxAddressLineIndex() > 0 ? address
                            .getAddressLine(0) : "", address.getCountryName());



            mMap.clear();
            mMap.addMarker(new MarkerOptions().position(latLng).title(addressText));

            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
        }

        //locationTv.setText("Latitude:" + address.getLatitude() + ", Longitude:" + address.getLongitude());


    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                }
            }


        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        locationManager =(LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener=new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                //Toast.makeText(MapsActivity.this,location.toString(),Toast.LENGTH_SHORT).show();
                // Add a marker in Sydney and move the camera
                LatLng UserLocation = new LatLng(location.getLatitude(), location.getLongitude());
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(UserLocation).title("Your Location"));
                // mMap.moveCamera(CameraUpdateFactory.newLatLng(UserLocation));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(UserLocation,13));
                Geocoder geocoder=new Geocoder(getApplicationContext(), Locale.getDefault());
                try {
                    List<Address> listAddresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(),1);
                    if(listAddresses != null && listAddresses.size()>0)
                    {
                        Log.i("PlaceInfo",listAddresses.get(0).toString());

                        String address="";
                        if(listAddresses.get(0).getSubThoroughfare() !=null){
                            address+=listAddresses.get(0).getSubThoroughfare()+"";
                        }
                        if(listAddresses.get(0).getThoroughfare() !=null){
                            address+=listAddresses.get(0).getThoroughfare()+", ";
                        }
                        if(listAddresses.get(0).getLocality() !=null){
                            address+=listAddresses.get(0).getLocality()+", ";
                        }
                        if(listAddresses.get(0).getPostalCode() !=null){
                            address+=listAddresses.get(0).getPostalCode()+", ";
                        }
                        if(listAddresses.get(0).getCountryName() !=null){
                            address+=listAddresses.get(0).getCountryName()+", ";
                        }
                        Toast.makeText(MapsActivity.this,address,Toast.LENGTH_SHORT).show();

                    }
                }catch (Exception e)
                {
                    e.printStackTrace();

                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };
       /* if(Build.VERSION.SDK_INT<23){
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,0,0,locationListener);
        }else{
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED)
            {

            }
        }*/
        if (Build.VERSION.SDK_INT < 23) {
            if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED)
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        } else {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                //ask for permission
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                Location lastKnownLocation =null;
                lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
                {
                    //lastKnownLocation=mMap.getMyLocation();
                    try {
                        if (lastKnownLocation != null) {
                            Log.i("location", lastKnownLocation.toString());
                            LatLng UserLocation = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                            mMap.clear();
                            String address="";

                            Geocoder geocoder=new Geocoder(getApplicationContext(), Locale.getDefault());
                            try {
                                List<Address> listAddresses = geocoder.getFromLocation(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(),1);
                                if(listAddresses != null && listAddresses.size()>0)
                                {
                                    Log.i("PlaceInfo",listAddresses.get(0).toString());


                                    if(listAddresses.get(0).getSubThoroughfare() !=null){
                                        address+=listAddresses.get(0).getSubThoroughfare()+"";
                                    }
                                    if(listAddresses.get(0).getThoroughfare() !=null){
                                        address+=listAddresses.get(0).getThoroughfare()+", ";
                                    }
                                    if(listAddresses.get(0).getLocality() !=null){
                                        address+=listAddresses.get(0).getLocality()+", ";
                                    }
                                    if(listAddresses.get(0).getPostalCode() !=null){
                                        address+=listAddresses.get(0).getPostalCode()+", ";
                                    }
                                    if(listAddresses.get(0).getCountryName() !=null){
                                        address+=listAddresses.get(0).getCountryName()+", ";
                                    }
                                    Toast.makeText(MapsActivity.this,address,Toast.LENGTH_SHORT).show();

                                }
                            }catch (Exception e)
                            {
                                e.printStackTrace();

                            }
                            mMap.addMarker(new MarkerOptions().position(UserLocation).title("Your Location:"+address));
                            //mMap.moveCamera(CameraUpdateFactory.newLatLng(UserLocation));
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(UserLocation,13));
                        }
                        else{
                            Log.i("location", "location null");
                        }



                    }catch (Exception e)
                    {
                        //Log.i("msg","exception");
                    }
                }else{
                    Log.i("msg","error");
                }


            }
        }



    }
    public void currentlocation(View v) {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //ask for permission
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        Location lastKnownLocation =null;
        lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))
        {
            //lastKnownLocation=mMap.getMyLocation();
            try {
                if (lastKnownLocation != null) {
                    Log.i("location", lastKnownLocation.toString());
                    LatLng UserLocation = new LatLng(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude());
                    mMap.clear();
                    String address="";
                    //mMap.moveCamera(CameraUpdateFactory.newLatLng(UserLocation));

                    Geocoder geocoder=new Geocoder(getApplicationContext(), Locale.getDefault());
                    try {
                        List<Address> listAddresses = geocoder.getFromLocation(lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(),1);
                        if(listAddresses != null && listAddresses.size()>0)
                        {
                            Log.i("PlaceInfo",listAddresses.get(0).toString());


                            if(listAddresses.get(0).getSubThoroughfare() !=null){
                                address+=listAddresses.get(0).getSubThoroughfare()+"";
                            }
                            if(listAddresses.get(0).getThoroughfare() !=null){
                                address+=listAddresses.get(0).getThoroughfare()+", ";
                            }
                            if(listAddresses.get(0).getLocality() !=null){
                                address+=listAddresses.get(0).getLocality()+", ";
                            }
                            if(listAddresses.get(0).getPostalCode() !=null){
                                address+=listAddresses.get(0).getPostalCode()+", ";
                            }
                            if(listAddresses.get(0).getCountryName() !=null){
                                address+=listAddresses.get(0).getCountryName()+", ";
                            }
                            Toast.makeText(MapsActivity.this,address,Toast.LENGTH_SHORT).show();


                        }
                    }catch (Exception e)
                    {
                        e.printStackTrace();

                    }
                    mMap.addMarker(new MarkerOptions().position(UserLocation).title("Your Location:"+address));
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(UserLocation,13));
                }
                else{
                    Log.i("location", "location null");
                }



            }catch (Exception e)
            {
                //Log.i("msg","exception");
            }
        }else{
            Log.i("msg","error");
        }

    }
}
