package com.tvisha.servicedemo;

/*public class MyService {
}*/
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service {

    public int count=0;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onCreate() {
        Toast.makeText(this, "Service Created count: "+count, Toast.LENGTH_LONG).show();

    }
    @Override
    public void onStart(Intent intent, int startid) {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
               count++;
            }

        },0,1000);//Update text every second
        Toast.makeText(this, "Service Started count: "+count, Toast.LENGTH_LONG).show();

    }
    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service Stopped count:"+count, Toast.LENGTH_LONG).show();

    }
}