package com.tvisha.smssendingdemo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button send;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    String phoneNo;
    String message;
    EditText msg,number;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        send=findViewById(R.id.send);
        msg=findViewById(R.id.message);
        number=findViewById(R.id.number);
        msg.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ( event.getKeyCode() == KeyEvent.KEYCODE_ENTER) {
                    send.setEnabled(false);
                    validate();
                    return true;
                }
                return true;
            }
        });


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
            }
        });
      //  SmsManager smsManager = SmsManager.getDefault();
       // smsManager.sendTextMessage("phoneNo", null, "sms message", null, null);
    }
    private void validate(){
        message=msg.getText().toString();
        phoneNo=number.getText().toString();
        if(phoneNo.isEmpty() || phoneNo.length()<10)
        {
            Toast.makeText(getApplicationContext(), "Please enter mobile number", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else  if(message.isEmpty() || message.length()==0)
        {
            Toast.makeText(getApplicationContext(), "Please enter message", Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
        else
        {
            sendMessage();

        }

    }
    private void sendMessage(){
        closeKeyboard();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {

            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
        else
        {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, "9490832164", message, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent.",
                    Toast.LENGTH_LONG).show();
            send.setEnabled(true);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNo, null, message, null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();
                    send.setEnabled(true);
                }
            }
        }

    }
    private void closeKeyboard(){
        View view = this.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
       /*   password.setFocusableInTouchMode(true);
                    password.setFocusable(true);
                    password.requestFocus();
                    ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                            .showSoftInput(password, InputMethodManager.SHOW_FORCED);*/
}
