package com.tvisha.mounika.timer;

import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    SeekBar timerSeekBar;
     TextView timerTextView;
     Boolean counterIsActive=false;
     Button controlerButton;
     CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timerSeekBar=(SeekBar) findViewById(R.id.timerSeekBar);
        timerTextView=(TextView) findViewById(R.id.timerTextView);
        controlerButton=(Button) findViewById(R.id.controllerButton);
        timerSeekBar.setMax(600);
        timerSeekBar.setProgress(30);
        timerSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateTimer(progress);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


       /* new CountDownTimer(10000,1000){
            public void onTick(long milliSecondsUntilDone){
                //Countdown is counting down(every second)
                Log.i("Seconds left",String.valueOf(milliSecondsUntilDone / 1000));

            }
            public void onFinish(){
                //Counter if finished (after 10 seconds)
                Log.i("Done!","Countdown Timer finished");

            }
        }.start();*/

        /*final Handler handler=new Handler();
        Runnable run=new Runnable() {
            @Override
            public void run() {
                //zinsert code to be run every second
                Log.i("Runnable has run!","a second must have passed...");
                handler.postDelayed(this,1000);

            }
        };
        handler.post(run);*/


    }




     public void resetTimer(){
         timerTextView.setText("0:30");
         timerSeekBar.setProgress(30);
         countDownTimer.cancel();
         controlerButton.setText("Go");
         timerSeekBar.setEnabled(true);
         counterIsActive=false;
     }
    public void updateTimer(int secondsLeft){
        int minutes=(int) secondsLeft/60;
        int seconds=secondsLeft-minutes*60;
        String secondSting=Integer.toString(seconds);
         if(seconds<=9){
            secondSting="0"+secondSting;
        }
        timerTextView.setText(Integer.toString(minutes)+":"+secondSting);

    }
    public void controlTimer(View view) {
        if (counterIsActive == false) {
            counterIsActive = true;
            timerSeekBar.setEnabled(false);
            controlerButton.setText("Stop");
           countDownTimer= new CountDownTimer(timerSeekBar.getProgress() * 1000 + 100, 1000) {
                public void onTick(long millisUntilFinished) {
                    updateTimer((int) millisUntilFinished / 1000);
                }

                public void onFinish() {
                   resetTimer();
                    MediaPlayer mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.horn);
                    mediaPlayer.start();

                }


            }.start();
        }else
        {
          resetTimer();
        }
    }


}
